import SwiftUI

@main
struct InfinitySearchApp: App {
    var body: some Scene {
        WindowGroup {
            ImageGalleryView()
        }
    }
}
